
#!/bin/sh

# this basically replaces starts tomcat on n800, tested with tomcat 5.0.30 beta
# you will get a lot of errors about mbeans not loading, these are not supported by the gnu classpath
# after booting, took 443839 ms, you can access the server on localhost:8080, frontpage actually loads reasonably  fast
# mind you, that involves compiling a JSP!
PATH=/usr/local/bin:$PATH
CATALINA_HOME=/media/mmc2/tomcat
CLASSPATH=/usr/local/classpath/share/classpath/glibj.zip:"$CATALINA_HOME"/bin/bootstrap.jar:"$CATALINA_HOME"/bin/commons-logging-api.jar
CATALINA_BASE="$CATALINA_HOME"
CATALINA_TMPDIR="$CATALINA_HOME"/temp

jamvm -classpath "$CLASSPATH" \
      -Dcatalina.base="$CATALINA_BASE" \
      -Dcatalina.home="$CATALINA_HOME" \
      -Djava.io.tmpdir="$CATALINA_TMPDIR" \
      org.apache.catalina.startup.Bootstrap "$@" start
      
#      >> "$CATALINA_BASE"/logs/catalina.out 2>&1 &
