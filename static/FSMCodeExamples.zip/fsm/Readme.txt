All source is now covered under LGPL. It is still research code and I don't
accept any liability for its usage. Enjoy!

This directory contains the source and binaries for the enhanced statepattern. 
The details of this pattern are discussed in my paper "On the Implementation of 
Finite State Machines" (accepted for SEA '99).
The directory also contains the wrapatext example used in that paper as well as 
a larger example of a FSM. All code is written in Java and can be compiled with 
JDK 1.2 or better. JDK 1.1 is possible for all the non GUI classes only.

For your convenience a few scripts are provided to compile the source code and 
generate the documentation:
newstate\compile.bat 
wrapatext\compile.bat
generateDocumentation.bat

Also a few test scripts are provided:
FSMGenerate <xmlfile>
WrapATextTest.bat

note: the wrapatext example does not work with the FSMGenerate test script. This 
is because of the actions that cause exceptions when no proper data is sent 
along. The WrapAText example can be tested instead with the WrapATextTest.bat 
script.

Important classes

newstate.test.FSMGeneratorTest
wrapatext.TestNewState
wrapatext.TestState

Look in the corresponding source code to find examples of how to use the classes.

Questions can be sent to jilles@cs.rug.nl.
