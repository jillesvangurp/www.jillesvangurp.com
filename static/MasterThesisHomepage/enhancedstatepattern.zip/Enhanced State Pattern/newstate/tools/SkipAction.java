package newstate.tools;

import newstate.*;

public class SkipAction implements FSMAction
{
        public void execute(FSMContext fsmc, Object data)
        { // by default do nothing :)               
        }
}
