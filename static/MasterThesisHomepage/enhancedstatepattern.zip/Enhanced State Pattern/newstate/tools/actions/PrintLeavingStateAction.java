package newstate.tools.actions;

import newstate.*;

public class PrintLeavingStateAction implements java.io.Serializable, FSMAction
{
        public PrintLeavingStateAction()
        {
        }
        
        public void execute(FSMContext fsmc, Object o)
        {
                System.out.println("leaving " + fsmc.getState());
        }
}