package newstate.tools;

import java.io.*;
import newstate.*;

public class Serializer
{
        public static void serialize(Object o, String filename)
        {
                try
                {
                        FileOutputStream ostream = new FileOutputStream(filename);
                        ObjectOutputStream objstr = new ObjectOutputStream(ostream);
                        objstr.writeObject(o);
                        ostream.close();
                } 
                catch (Exception e) 
                {
                        e.printStackTrace();
                }
        }
        
        public static Object deserialize(String filename)
        {
                try
                {
                        FileInputStream istream = new FileInputStream(filename);
                        ObjectInputStream objstr = new ObjectInputStream(istream);
                        Object o = objstr.readObject();
                        istream.close();
                        return o;
                } 
                catch (Exception e) 
                {
                        e.printStackTrace();
                }
                return null;            
        }
        
/*        public static void main(String ps[])
        {
                PrintAction p = new PrintAction("Hello world!");
                
                serialize(p,"HelloWorldAction.ser");
                FSMAction f = (FSMAction)deserialize("HelloWorldAction.ser");
                f.execute(null,null);                
        }*/
}