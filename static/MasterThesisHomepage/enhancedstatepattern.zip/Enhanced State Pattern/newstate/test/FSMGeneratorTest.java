package newstate.test;

import newstate.*;
import newstate.tools.*;

class FSMGeneratorTest
{
        public static void main(String ps[])
        {
                // configure & serialize actions                
                newstate.tools.actions.MakeActions.doit();
                FSM fsm = FSMGenerator.generateFSM("test.xml");
                new FSMController(fsm.createFSMInstance()).show();
        }
}