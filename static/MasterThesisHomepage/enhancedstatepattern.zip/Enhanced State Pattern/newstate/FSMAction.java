package newstate;

/**
* The FSM uses the command pattern to implement actions. All actions must 
* implement this interface.
*/
public interface FSMAction
{
        /**
        * @param fsmc This is the context in which the command is executed. The
        * context can be used as a repository for objects. That is because
        * FSMContext extends from java.util.Hashtable. 
        * @param data Some extra data that can be given to a command
        */
        public void execute(FSMContext fsmc, Object data);
}