package orthogonalstate;

import java.util.*;

public class OrthogonalState extends State
{
        Vector children = new Vector(); // can only be nodestates

// check whether all submachines are in their default state
        boolean inDefaultStates(Vector subsetOfChildren)
        {
                boolean answer = true;
                for(Enumeration e = subsetOfChildren.elements() ;
                    e.hasMoreElements() ;)
                {
                        NodeState c = (NodeState)e.nextElement();
                        answer = answer && c.getDefaultState() == getState();
                }
                return answer;
        }
        
        public void addTransition(LeafState to,
                                           FSMEvent trigger,          
                                           FSMAction action)
        {
        }                                           

        public void addTransition(NodeState to,
                                           FSMEvent trigger,          
                                           FSMAction action)
        {
        }                                           

        public void addTransition(Vector to,
                                           FSMEvent trigger,          
                                           FSMAction action)
        {
                // check whether the to states are in one ortogonal state
                // (possibnly nested with other o states)
                
                // check whether this state is part of an o state
                // if so retrieve fellow default states
        }                  

        public void dispatch(FSMEvent trigger, 
                                      Object data, 
                                      FSMContext fsmc)
        {
        }                                           

        public Vector getEvents()
        {
                return new Vector();
        }                                           

}