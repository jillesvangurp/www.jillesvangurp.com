package orthogonalstate;

/**
* Transitions are created on the fly and should not be created manually.
*/
interface Transition
{        
        public void execute(FSMContext fsmc, Object data);
}