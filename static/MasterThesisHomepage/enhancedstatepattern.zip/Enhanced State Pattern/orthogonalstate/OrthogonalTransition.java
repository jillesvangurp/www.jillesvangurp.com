package orthogonalstate;

/**
* Transitions are created on the fly and should not be created manually.
*/
class OrthogonalTransition
{
        Vector source; // leafstates that form the starting point
        Vector target; // leafstates that form the end point
        
        FSMAction action;
        
        public void execute(FSMContext fsmc, Object data)
        {
                for(Enumeration e = source.elements() ; e.hasMoreElements() ;)
                {
                        LeafState s = (LeafState)e.nextElement();
                        for(Enumeration f = target.elements() ; 
                            f.hasMoreElements() ;)                            
                        {
                                LeafState t = (LeafState)f.nextElement();
                                new NormalTransition(s,
                                      t,action).execute(fsmc, data);
                        }
                }
        }
}