package orthogonalstate.tools.actions;

import nestedstate.*;

public class PrintLeavingStateAction implements java.io.Serializable, FSMAction
{
        public PrintLeavingStateAction()
        {
        }
        
        public void execute(FSMContext fsmc, Object o)
        {
                System.out.println("leaving " + fsmc.getState());
        }
}