package orthogonalstate.tools.actions;

import nestedstate.tools.*;

public class MakeActions
{
        public static void doit()
        {
                Serializer.serialize(new PrintAction("Hello world"), "Helloworld.ser");
                Serializer.serialize(new PrintLeavingStateAction(), "leave.ser");
                Serializer.serialize(new PrintEnteringStateAction(), "enter.ser");
        }

        public static void main(String ps[])
        {
        }
}