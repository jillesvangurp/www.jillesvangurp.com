pacakge statepattern;

public interface State
{
}