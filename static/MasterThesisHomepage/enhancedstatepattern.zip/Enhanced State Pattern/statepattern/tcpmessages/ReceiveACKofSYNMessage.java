package statepattern.tcpmessages;

import statepattern.*;

public class ReceiveACKofSYNMessage implements ContextVisitor
{
        public void at(Context c, Object data)
        {
        }
}