package statepattern.tcpmessages;

import statepattern.*;

public class CloseMessage implements ContextVisitor
{
        public void at(Context c, Object data)
        {
        }
}