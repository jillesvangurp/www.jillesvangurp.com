package statepattern.tcpmessages;

import statepattern.*;

public class SendMessage implements ContextVisitor
{
        public void at(Context c, Object data)
        {
        }
}