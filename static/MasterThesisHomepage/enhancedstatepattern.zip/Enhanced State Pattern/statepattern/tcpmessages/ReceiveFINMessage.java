package statepattern.tcpmessages;

import statepattern.*;

public class ReceiveFINMessage implements ContextVisitor
{
        public void at(Context c, Object data)
        {
        }
}