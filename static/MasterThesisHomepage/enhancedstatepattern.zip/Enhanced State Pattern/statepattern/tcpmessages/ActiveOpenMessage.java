package statepattern.tcpmessages;

import statepattern.*;

public class ActiveOpenMessage implements ContextVisitor
{
        public void at(Context c, Object data)
        {
        }
}