package statepattern.tcpmessages;

import statepattern.*;

public class ReceiveSYNMessage implements ContextVisitor
{
        public void at(Context c, Object data)
        {
        }
}