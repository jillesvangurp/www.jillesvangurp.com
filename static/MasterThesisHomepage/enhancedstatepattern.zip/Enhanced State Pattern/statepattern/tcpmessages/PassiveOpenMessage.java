package statepattern.tcpmessages;

import statepattern.*;

public class PassiveOpenMessage implements ContextVisitor
{
        public void at(Context c, Object data)
        {
        }
}