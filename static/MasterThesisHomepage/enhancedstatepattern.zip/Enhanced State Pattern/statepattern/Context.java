package statepattern;

public class Context
{
        State current;

        public void setState(State s)
        {
                current = s;
        }
        
        public State getState()
        {
                return current;
        }
        
        public void accept(ContextVisitor cv, Object data)
        {
                cv.at(this, data)
        }
}