package statepattern.tcpstates;

import statepattern.*;

public class FINWait1State implements State
{
}