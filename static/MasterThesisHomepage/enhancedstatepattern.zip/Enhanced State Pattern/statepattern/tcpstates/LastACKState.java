package statepattern.tcpstates;

import statepattern.*;

public class LastACKState implements State
{
}