package statepattern.tcpstates;

import statepattern.*;

public class EstablishedState implements State
{
}