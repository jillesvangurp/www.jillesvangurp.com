package statepattern.tcpstates;

import statepattern.*;

public class ClosingState implements State
{
}