package statepattern.tcpstates;

import statepattern.*;

public class SYNReceivedState implements State
{
}