package statepattern.tcpstates;

import statepattern.*;

public class ListenState implements State
{
}