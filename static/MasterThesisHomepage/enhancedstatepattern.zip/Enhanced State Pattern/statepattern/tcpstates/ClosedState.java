package statepattern.tcpstates;

import statepattern.*;

public class ClosedState implements State
{
}