package statepattern.tcpstates;

import statepattern.*;

public class SYNSentState implements State
{
}