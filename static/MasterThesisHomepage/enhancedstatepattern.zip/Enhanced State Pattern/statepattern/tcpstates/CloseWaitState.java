package statepattern.tcpstates;

import statepattern.*;

public class CloseWaitState implements State
{
}