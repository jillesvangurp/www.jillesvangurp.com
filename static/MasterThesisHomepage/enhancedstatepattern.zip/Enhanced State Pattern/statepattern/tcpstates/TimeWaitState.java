package statepattern.tcpstates;

import statepattern.*;

public class TimeWaitState implements State
{
}