package statepattern;

public interface ContextVisitor
{
        public void at(Context c, Object data);
}