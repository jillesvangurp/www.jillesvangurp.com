package nestedstate.tools;

import nestedstate.*;

public class WriteLogAction implements FSMAction
{
        String message = null;        
        
        public WriteLogAction(String s)
        {
                setMessage(s);
        }
        
        public void setMessage(String s) { message = s; }
        public String getMessage() { return message; }
        
        public void execute(FSMContext fsmc, Object data)
        {
                if(getMessage() != null) 
                        System.out.println(getMessage());
        }
}