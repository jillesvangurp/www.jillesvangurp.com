package nestedstate.tools.actions;

import nestedstate.*;

public class PrintAction implements java.io.Serializable, FSMAction
{
        String text;
        
        public PrintAction()
        {
        }

        public PrintAction(String s)
        {
                setText(s);
        }
        
        public void setText(String s)
        {
                text = s;
        }
        
        public String getText()
        {
                return text;
        }
        
        public void execute(FSMContext fsmc, Object o)
        {
                System.out.println(text);
        }
}
