package nestedstate.tools.actions;

import nestedstate.*;

public class PrintEnteringStateAction implements java.io.Serializable, FSMAction
{
        public PrintEnteringStateAction()
        {
        }
        
        public void execute(FSMContext fsmc, Object o)
        {
                System.out.println("entering " + fsmc.getState());
        }
}