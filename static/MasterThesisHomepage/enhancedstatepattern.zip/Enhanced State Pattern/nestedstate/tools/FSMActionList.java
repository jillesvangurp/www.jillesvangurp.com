package nestedstate.tools;

import java.util.*;
import nestedstate.*;

public class FSMActionList implements FSMAction
{
        Vector actions = new Vector();
        
        public void add(FSMAction a)
        {
                actions.addElement(a);
        }
        
        public void execute(FSMContext fsmc, Object data)
        {
                for(int i=0 ; i<actions.size() ; i++)
                {
                        ((FSMAction)actions.elementAt(i)).execute(fsmc, data);
                }
        }

}