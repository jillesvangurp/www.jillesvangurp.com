package nestedstate.tools;

import nestedstate.*;

public class SkipAction implements FSMAction
{
        public void execute(FSMContext fsmc, Object data)
        { // by default do nothing :)               
        }
}
