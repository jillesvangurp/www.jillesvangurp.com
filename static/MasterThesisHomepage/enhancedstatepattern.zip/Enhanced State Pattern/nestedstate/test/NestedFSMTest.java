package nestedstate.test;

import nestedstate.*;
import nestedstate.tools.*;

class NestedFSMTest
{
        FSMAction donothing = new FSMAction() {
                public void execute(FSMContext fsmc, Object data)
                {
                }
        };
        
        public NestedFSMTest()
        {
                // configure & serialize actions                
                nestedstate.tools.actions.MakeActions.doit();
                FSM fsm = FSMGenerator.generateFSM("nestedtest.xml");
                FSMContext fsmc = fsm.createFSMInstance();
                new FSMController(fsmc).show();
        }
       
        public static void main(String ps[])
        {
                new NestedFSMTest();
        }
}