package nestedstate;

public class FSMEvent
{
        public String name;
        
        /**
        * Creates an event with name s
        * @param s The name of the new event
        */
        public FSMEvent(String s)
        {
                setName(s);
        }
        
        public void setName(String s)
        {
                name = s;
        }

        public String getName()
        {
                return name;
        }
        
        /**
        * @return The name of the event
        */
        public String toString()
        {
                return getName();
        }
}